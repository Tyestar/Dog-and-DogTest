package mylesB;

//****************************************************************
//DogTest.java
//
//A simple test class that creates a Dog and makes it speak.
//
//****************************************************************
public class DogTest
{
	public static void main(String[] args)
	{
		Dog Gerald = new Labrador("Gerald", "black");
		System.out.println(Gerald.getName() + " says " + Gerald.speak());
		System.out.print("The average weight of a labrador is: ");
		System.out.println(Gerald.avgBreedWeight());
		
		Dog Requis = new Yorkshire("Requis");
		System.out.println(Requis.getName() + " says " + Requis.speak());
		System.out.print("The average weight of a Yorkshire  is: ");
		System.out.println(Requis.avgBreedWeight());
	}
}